import Foundation

let networkFileProvider: NetworkFileProvider = MockNetworkFileProvider()

DispatchQueue.global(qos: .default).async {
    do {
        let smallFile = try networkFileProvider.getSmallFileAsync()
        let fileSize = smallFile.count / 1024 / 1024
        print("SmallFile Size", fileSize, "MiB")
    } catch {
        print("Error getting small file.", error)
    }

    print("\n")
    do {
        let mediumFile = try networkFileProvider.getMediumFileAsync()
        let fileSize = mediumFile.count / 1024 / 1024
        print("MediumFile Size", fileSize, "MiB")
    } catch {
        print("Error getting medium file.", error)
    }

    print("\n")
    do {
        let largeFile = try networkFileProvider.getLargeFileAsync()
        let fileSize = largeFile.count / 1024 / 1024
        print("LargeFile Size", fileSize, "MiB")
    } catch {
        print("Error getting large file.", error)
    }
}
