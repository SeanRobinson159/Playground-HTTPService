import Foundation

public enum NetworkFileProviderError: Error {
    case badURL
}

public protocol NetworkFileProvider {
    func getSmallFileAsync() throws -> Data
    func getMediumFileAsync() throws -> Data
    func getLargeFileAsync() throws -> Data
}

public class MockNetworkFileProvider: NetworkFileProvider {
    private let httpService: HTTPService
    
    public init(_ httpService: HTTPService = DefaultHTTPService()) {
        self.httpService = httpService
    }
    
    public func getSmallFileAsync() throws -> Data {
        guard let url = URL(string: "http://ipv4.download.thinkbroadband.com/5MB.zip") else {
            throw NetworkFileProviderError.badURL
        }
        
        return try self.httpService.getDataAsync(url)
    }
    
    public func getMediumFileAsync() throws -> Data {
        guard let url = URL(string: "http://ipv4.download.thinkbroadband.com/10MB.zip") else {
            throw NetworkFileProviderError.badURL
        }
        
        return try self.httpService.getDataAsync(url)
    }
    
    public func getLargeFileAsync() throws -> Data {
        guard let url = URL(string: "http://ipv4.download.thinkbroadband.com/20MB.zip") else {
            throw NetworkFileProviderError.badURL
        }
        
        return try self.httpService.getDataAsync(url)
    }
}

