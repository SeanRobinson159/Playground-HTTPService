import Foundation

public enum HTTPServiceError: Error {
    case unknownStatusCode
    case badStatusCode
    case noResponseData
}

public protocol HTTPService {
    func getDataAsync(_ url: URL) throws -> Data
}

public class DefaultHTTPService: HTTPService {
    private let session: URLSession
    
    public init(session: URLSession = URLSession.shared) {
        self.session = session
    }
    
    public func getDataAsync(_ url: URL) throws -> Data {
        print("GET", url.absoluteString)
        
        let response = try startRequestAsync(url)
        
        guard let httpURLResponse = response.1 as? HTTPURLResponse else {
            throw HTTPServiceError.unknownStatusCode
        }
        
        print(httpURLResponse.statusCode, url.absoluteString)
        
        guard httpURLResponse.statusCode < 400 else {
            throw HTTPServiceError.badStatusCode
        }
        
        guard let data = response.0 else {
            throw HTTPServiceError.noResponseData
        }
        
        return data
    }
    
    private func startRequestAsync(_ url: URL) throws -> (Data?, URLResponse?) {
        self.logThreadWarningIfNeeded()
        
        let group = DispatchGroup()
        
        var data: Data?
        var urlResponse: URLResponse?
        var error: Error?
        
        group.enter()
        let task = self.session.dataTask(with: url, completionHandler: {
            data = $0
            urlResponse = $1
            error = $2
            group.leave()
        })
        
        task.resume()
        
        group.wait()
        
        if let error = error {
            throw error
        }
        
        return (data, urlResponse)
    }
    
    private func logThreadWarningIfNeeded() {
        guard Thread.isMainThread else { return }
        
        print(
            """
            !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            ASYNC NETWORK CALLS SHOULD NOT BE CALLED ON THE MAIN THREAD
            !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            """
        )
    }
}

